<?php
$config = array(
	'name' => 'Slovenian (Slovenia)',
	'locale' => 'sl_SI',
	'author' => 'Mautic Translators',
);

return $config;