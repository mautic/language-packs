<?php
$config = [
	'name' => 'Arabic',
	'locale' => 'ar',
	'author' => 'Mautic Translators',
];

return $config;