<?php
$config = array(
	'name' => 'Arabic',
	'locale' => 'ar',
	'author' => 'Mautic Translators',
);

return $config;