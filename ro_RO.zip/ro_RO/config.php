<?php
$config = [
	'name' => 'Romanian (Romania)',
	'locale' => 'ro_RO',
	'author' => 'Mautic Translators',
];

return $config;