<?php
$config = array(
	'name' => 'Romanian (Romania)',
	'locale' => 'ro_RO',
	'author' => 'Mautic Translators',
);

return $config;