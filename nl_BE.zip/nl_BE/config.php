<?php
$config = [
	'name' => 'Dutch (Belgium)',
	'locale' => 'nl_BE',
	'author' => 'Mautic Translators',
];

return $config;