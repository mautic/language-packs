<?php
$config = [
	'name' => 'Ukrainian (Ukraine)',
	'locale' => 'uk_UA',
	'author' => 'Mautic Translators',
];

return $config;