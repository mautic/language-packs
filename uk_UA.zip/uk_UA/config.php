<?php
$config = array(
	'name' => 'Ukrainian (Ukraine)',
	'locale' => 'uk_UA',
	'author' => 'Mautic Translators',
);

return $config;