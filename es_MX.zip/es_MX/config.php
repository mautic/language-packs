<?php
$config = [
	'name' => 'Spanish (Mexico)',
	'locale' => 'es_MX',
	'author' => 'Mautic Translators',
];

return $config;