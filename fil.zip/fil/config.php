<?php
$config = [
	'name' => 'Filipino',
	'locale' => 'fil',
	'author' => 'Mautic Translators',
];

return $config;