<?php
$config = array(
	'name' => 'Filipino',
	'locale' => 'fil',
	'author' => 'Mautic Translators',
);

return $config;