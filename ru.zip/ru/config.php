<?php
$config = [
	'name' => 'Russian',
	'locale' => 'ru',
	'author' => 'Mautic Translators',
];

return $config;