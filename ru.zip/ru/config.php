<?php
$config = array(
	'name' => 'Russian',
	'locale' => 'ru',
	'author' => 'Mautic Translators',
);

return $config;