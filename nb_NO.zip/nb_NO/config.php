<?php
$config = array(
	'name' => 'Norwegian Bokmål (Norway)',
	'locale' => 'nb_NO',
	'author' => 'Mautic Translators',
);

return $config;