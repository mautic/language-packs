<?php
$config = [
	'name' => 'Norwegian Bokmål (Norway)',
	'locale' => 'nb_NO',
	'author' => 'Mautic Translators',
];

return $config;