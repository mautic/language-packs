<?php
$config = array(
	'name' => 'Hungarian',
	'locale' => 'hu',
	'author' => 'Mautic Translators',
);

return $config;