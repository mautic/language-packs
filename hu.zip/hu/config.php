<?php
$config = [
	'name' => 'Hungarian',
	'locale' => 'hu',
	'author' => 'Mautic Translators',
];

return $config;