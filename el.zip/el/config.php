<?php
$config = [
	'name' => 'Greek',
	'locale' => 'el',
	'author' => 'Mautic Translators',
];

return $config;