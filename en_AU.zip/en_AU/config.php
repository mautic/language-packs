<?php
$config = [
	'name' => 'English (Australia)',
	'locale' => 'en_AU',
	'author' => 'Mautic Translators',
];

return $config;