<?php
$config = [
	'name' => 'Hindi (India)',
	'locale' => 'hi_IN',
	'author' => 'Mautic Translators',
];

return $config;