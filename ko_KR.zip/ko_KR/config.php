<?php
$config = [
	'name' => 'Korean (Korea)',
	'locale' => 'ko_KR',
	'author' => 'Mautic Translators',
];

return $config;