<?php
$config = [
	'name' => 'Thai',
	'locale' => 'th',
	'author' => 'Mautic Translators',
];

return $config;