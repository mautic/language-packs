<?php
$config = array(
	'name' => 'Thai',
	'locale' => 'th',
	'author' => 'Mautic Translators',
);

return $config;