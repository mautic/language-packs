<?php
$config = array(
	'name' => 'Basque',
	'locale' => 'eu',
	'author' => 'Mautic Translators',
);

return $config;