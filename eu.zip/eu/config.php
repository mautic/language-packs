<?php
$config = [
	'name' => 'Basque',
	'locale' => 'eu',
	'author' => 'Mautic Translators',
];

return $config;