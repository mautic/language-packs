<?php
$config = [
	'name' => 'Hebrew (Israel)',
	'locale' => 'he_IL',
	'author' => 'Mautic Translators',
];

return $config;