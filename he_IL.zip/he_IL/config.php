<?php
$config = array(
	'name' => 'Hebrew (Israel)',
	'locale' => 'he_IL',
	'author' => 'Mautic Translators',
);

return $config;