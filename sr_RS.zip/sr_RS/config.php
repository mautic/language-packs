<?php
$config = [
	'name' => 'Serbian (Serbia)',
	'locale' => 'sr_RS',
	'author' => 'Mautic Translators',
];

return $config;