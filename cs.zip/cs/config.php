<?php
$config = array(
	'name' => 'Czech',
	'locale' => 'cs',
	'author' => 'Mautic Translators',
);

return $config;