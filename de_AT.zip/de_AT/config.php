<?php
$config = [
	'name' => 'German (Austria)',
	'locale' => 'de_AT',
	'author' => 'Mautic Translators',
];

return $config;