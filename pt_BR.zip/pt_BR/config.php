<?php
$config = [
	'name' => 'Portuguese (Brazil)',
	'locale' => 'pt_BR',
	'author' => 'Mautic Translators',
];

return $config;