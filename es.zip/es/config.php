<?php
$config = array(
	'name' => 'Spanish',
	'locale' => 'es',
	'author' => 'Mautic Translators',
);

return $config;