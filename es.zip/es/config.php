<?php
$config = [
	'name' => 'Spanish',
	'locale' => 'es',
	'author' => 'Mautic Translators',
];

return $config;