<?php
$config = [
	'name' => 'Russian (Russia)',
	'locale' => 'ru_RU',
	'author' => 'Mautic Translators',
];

return $config;