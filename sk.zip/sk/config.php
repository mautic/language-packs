<?php
$config = [
	'name' => 'Slovak',
	'locale' => 'sk',
	'author' => 'Mautic Translators',
];

return $config;