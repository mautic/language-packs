<?php
$config = array(
	'name' => 'German (Switzerland)',
	'locale' => 'de_CH',
	'author' => 'Mautic Translators',
);

return $config;