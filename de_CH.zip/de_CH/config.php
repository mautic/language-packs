<?php
$config = [
	'name' => 'German (Switzerland)',
	'locale' => 'de_CH',
	'author' => 'Mautic Translators',
];

return $config;