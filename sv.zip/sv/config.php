<?php
$config = [
	'name' => 'Swedish',
	'locale' => 'sv',
	'author' => 'Mautic Translators',
];

return $config;