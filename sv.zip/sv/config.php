<?php
$config = array(
	'name' => 'Swedish',
	'locale' => 'sv',
	'author' => 'Mautic Translators',
);

return $config;