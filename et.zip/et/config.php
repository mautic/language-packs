<?php
$config = [
	'name' => 'Estonian',
	'locale' => 'et',
	'author' => 'Mautic Translators',
];

return $config;