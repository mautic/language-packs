<?php
$config = array(
	'name' => 'Indonesian (Indonesia)',
	'locale' => 'id_ID',
	'author' => 'Mautic Translators',
);

return $config;