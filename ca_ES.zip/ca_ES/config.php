<?php
$config = [
	'name' => 'Catalan (Spain)',
	'locale' => 'ca_ES',
	'author' => 'Mautic Translators',
];

return $config;