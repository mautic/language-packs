<?php
$config = [
	'name' => 'Finnish (Finland)',
	'locale' => 'fi_FI',
	'author' => 'Mautic Translators',
];

return $config;