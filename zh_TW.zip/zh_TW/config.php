<?php
$config = [
	'name' => 'Chinese (Taiwan)',
	'locale' => 'zh_TW',
	'author' => 'Mautic Translators',
];

return $config;