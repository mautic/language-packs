<?php
$config = array(
	'name' => 'Chinese Simplified',
	'locale' => 'zh_Hans',
	'author' => 'Mautic Translators',
);

return $config;