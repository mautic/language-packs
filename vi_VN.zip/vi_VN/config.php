<?php
$config = [
	'name' => 'Vietnamese (Viet Nam)',
	'locale' => 'vi_VN',
	'author' => 'Mautic Translators',
];

return $config;