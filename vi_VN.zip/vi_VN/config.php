<?php
$config = array(
	'name' => 'Vietnamese (Viet Nam)',
	'locale' => 'vi_VN',
	'author' => 'Mautic Translators',
);

return $config;