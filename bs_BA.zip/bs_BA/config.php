<?php
$config = [
	'name' => 'Bosnian (Bosnia and Herzegovina)',
	'locale' => 'bs_BA',
	'author' => 'Mautic Translators',
];

return $config;