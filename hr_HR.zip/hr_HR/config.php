<?php
$config = [
	'name' => 'Croatian (Croatia)',
	'locale' => 'hr_HR',
	'author' => 'Mautic Translators',
];

return $config;