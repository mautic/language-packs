<?php
$config = array(
	'name' => 'Italian (Italy)',
	'locale' => 'it_IT',
	'author' => 'Mautic Translators',
);

return $config;