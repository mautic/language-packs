<?php
$config = [
	'name' => 'Hindi',
	'locale' => 'hi',
	'author' => 'Mautic Translators',
];

return $config;