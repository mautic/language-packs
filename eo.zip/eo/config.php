<?php
$config = array(
	'name' => 'Esperanto',
	'locale' => 'eo',
	'author' => 'Mautic Translators',
);

return $config;