<?php
$config = [
	'name' => 'Esperanto',
	'locale' => 'eo',
	'author' => 'Mautic Translators',
];

return $config;