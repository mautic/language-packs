<?php
$config = [
	'name' => 'Persian (Iran)',
	'locale' => 'fa_IR',
	'author' => 'Mautic Translators',
];

return $config;