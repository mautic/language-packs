<?php
$config = [
	'name' => 'Danish',
	'locale' => 'da',
	'author' => 'Mautic Translators',
];

return $config;