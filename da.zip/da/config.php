<?php
$config = array(
	'name' => 'Danish',
	'locale' => 'da',
	'author' => 'Mautic Translators',
);

return $config;