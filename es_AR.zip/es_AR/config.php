<?php
$config = [
	'name' => 'Spanish (Argentina)',
	'locale' => 'es_AR',
	'author' => 'Mautic Translators',
];

return $config;