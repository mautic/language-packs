<?php
$config = [
	'name' => 'Chinese Simplified',
	'locale' => 'zh-Hans',
	'author' => 'Mautic Translators',
];

return $config;