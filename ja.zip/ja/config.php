<?php
$config = [
	'name' => 'Japanese',
	'locale' => 'ja',
	'author' => 'Mautic Translators',
];

return $config;