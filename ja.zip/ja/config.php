<?php
$config = array(
	'name' => 'Japanese',
	'locale' => 'ja',
	'author' => 'Mautic Translators',
);

return $config;