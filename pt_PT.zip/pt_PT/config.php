<?php
$config = [
	'name' => 'Portuguese (Portugal)',
	'locale' => 'pt_PT',
	'author' => 'Mautic Translators',
];

return $config;