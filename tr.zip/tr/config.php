<?php
$config = [
	'name' => 'Turkish',
	'locale' => 'tr',
	'author' => 'Mautic Translators',
];

return $config;