<?php
$config = array(
	'name' => 'Turkish',
	'locale' => 'tr',
	'author' => 'Mautic Translators',
);

return $config;