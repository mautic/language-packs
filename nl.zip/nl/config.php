<?php
$config = array(
	'name' => 'Dutch',
	'locale' => 'nl',
	'author' => 'Mautic Translators',
);

return $config;