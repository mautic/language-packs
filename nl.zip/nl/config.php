<?php
$config = [
	'name' => 'Dutch',
	'locale' => 'nl',
	'author' => 'Mautic Translators',
];

return $config;