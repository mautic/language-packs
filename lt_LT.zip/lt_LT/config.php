<?php
$config = [
	'name' => 'Lithuanian (Lithuania)',
	'locale' => 'lt_LT',
	'author' => 'Mautic Translators',
];

return $config;