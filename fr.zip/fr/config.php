<?php
$config = [
	'name' => 'French',
	'locale' => 'fr',
	'author' => 'Mautic Translators',
];

return $config;