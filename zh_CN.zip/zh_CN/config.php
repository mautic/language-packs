<?php
$config = array(
	'name' => 'Chinese (China)',
	'locale' => 'zh_CN',
	'author' => 'Mautic Translators',
);

return $config;