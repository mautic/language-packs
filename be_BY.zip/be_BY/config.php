<?php
$config = [
	'name' => 'Belarusian (Belarus)',
	'locale' => 'be_BY',
	'author' => 'Mautic Translators',
];

return $config;