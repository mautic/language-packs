<?php
$config = [
	'name' => 'Macedonian (Macedonia)',
	'locale' => 'mk_MK',
	'author' => 'Mautic Translators',
];

return $config;