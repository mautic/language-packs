<?php
$config = array(
	'name' => 'Bulgarian (Bulgaria)',
	'locale' => 'bg_BG',
	'author' => 'Mautic Translators',
);

return $config;