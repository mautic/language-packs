<?php
$config = [
	'name' => 'German',
	'locale' => 'de',
	'author' => 'Mautic Translators',
];

return $config;