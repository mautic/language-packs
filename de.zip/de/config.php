<?php
$config = array(
	'name' => 'German',
	'locale' => 'de',
	'author' => 'Mautic Translators',
);

return $config;